# Enthält globale Projektkonfigurationen

PREDEFINED_SYMBOLS = ["AAPL", "GOOG"]
CAPITAL = 1000000
COMMISSION = 0.001
