"""
# RSI Strategie
Diese Strategie nutzt den Relative Strength Index zur Signalgenerierung.
"""