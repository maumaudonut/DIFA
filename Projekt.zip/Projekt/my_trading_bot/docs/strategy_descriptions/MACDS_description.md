"""
# MACD Strategie
Diese Strategie basiert auf dem Moving Average Convergence Divergence (MACD).
"""